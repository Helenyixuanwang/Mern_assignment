import React, { Component } from 'react';


class PersonCardClass extends Component  {
    constructor(props) {
        super(props);
            this.state = {
            age: this.props.age,
        }
    }
    render () {
     
    return (
        <div className = "text-centered">
            <h2> { this.props.lastName }, { this.props.firstName }</h2>
            <p> age : { this.state.age }</p>
            <p> haircolor : { this.props.hairColor }</p>
            <button onClick={ ()=>this.setState({age:this.state.age+1}) }>Birthday button for {this.props.firstName} {this.props.lastName}</button>
            
        </div>
    );
    
    }
}
    


export default PersonCardClass;