
import './App.css';
import PersonCardClass from './components/PersonCardClass';

function App() {
  return (
    <div className="App">
       <PersonCardClass firstName= {"Merry"}
                lastName={"Streep"}
                age={ 66 }
                hairColor={"brown"} />
    <PersonCardClass firstName={"John"}
                lastName={"Smith"}
                age={ 88 }
                hairColor={"brown"} />
    <PersonCardClass firstName={"Curtis"}
                lastName={"Chan"}
                age={ 26 }
                hairColor={"black"} />
    <PersonCardClass firstName={"Ashly"}
                lastName={"Liu"}
                age={ 36 }
                hairColor={"black"} />
     
    </div>
  );
}

export default App;
