
import './App.css';
import { Router } from "@reach/router";
import Home from './components/Home';
import Contact from './components/Contact';
import DisplayIntStr from './components/DisplayIntStr';


import DisplayStrStrNum from './components/DisplayStrStrNum';


function App() {
  return (
    <div className="App">
    <Router>
      <Home path="/home" />
      <Contact path="/contact" />
      <DisplayIntStr path="/:int" />
      <DisplayStrStrNum path="/:txt/:txtcolor/:backgndcolor" />
    </Router>
    </div>
  );
}

export default App;
