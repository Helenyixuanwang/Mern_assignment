const DisplayStrStrNum = (props) => {
    return (  <div style={{color:props.txtcolor, height:"30px", backgroundColor:props.backgndcolor}}>
        The word is : { props.txt }
    </div>);
}
 
export default DisplayStrStrNum;