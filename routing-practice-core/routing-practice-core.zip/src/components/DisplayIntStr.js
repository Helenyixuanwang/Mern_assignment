const DisplayIntStr = (props) => {
    // Hint: use the isNaN method (is Not a Number). For example: isNaN(+"35") is false, isNaN(+"hello") is true
    if (isNaN(props.int)) return  <h1> The word is {props.int}</h1> ;

    else return <h1> The number is { props.int }</h1>
}
 
export default DisplayIntStr;