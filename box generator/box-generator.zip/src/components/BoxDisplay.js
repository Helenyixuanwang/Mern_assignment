
    
const BoxDisplay= (props) => {
// using the getter that were passed from parent (App.js) component
  const { boxLst } = props;
    return (
        <div>
        {
          boxLst.map((box, index) => (
            <div key={index} style={{ 
                display: "inline-block",
                margin: "10px",
                height: box.size, 
                width: box.size, 
                backgroundColor: box.color,
                }}>
            </div>
          ))
        }
      </div>
    );
};
    
export default BoxDisplay;

