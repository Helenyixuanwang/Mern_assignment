
    
const MessageDisplay = (props) => {
    return (
        <>
            <h1>Current Message</h1>
            <p style={{color:props.message}}>{ props.message }</p>

            
           
            
        </>
    );
};
    
export default MessageDisplay;

