import React, { useState, useEffect} from 'react';
import axios from 'axios';
import './App.css';

function App() {
  const [people, setPeople] = useState([]);
  useEffect(()=> {
    console.log("useEffect function invoked");
    axios
    .get("https://swapi.dev/api/people")
    .then((response)=>setPeople(response.data.results))
    .catch((err)=>console.log(err))


  },[]);
  console.log("component render")
  
  return (
    <div className="App">
      { 
        people.length > 0 && people.map((person,index)=>(
          <div key={ index }>
          
          <p>{ person.name}</p>  
          <p>{ person.gender}</p>  
          <hr />
          </div>
        ))
      }
      
    </div>
  );
}

export default App;
