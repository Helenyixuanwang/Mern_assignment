import React, { useState, useEffect} from 'react';
import axios from 'axios';
import './App.css';

function App() {
  const [pokemon, setPokemon] = useState([]);
  useEffect(()=> {
    console.log("useEffect function invoked");
    axios
    .get("https://pokeapi.co/api/v2/pokemon?limit=807")
    .then((response)=>setPokemon(response.data.results))
    .catch((err)=>console.log(err))


  },[]);
  console.log("component render")
  
  return (
    <div className="App">
        <ul style={{textAlign:"center", listStylePosition:"inside"}}>
      { 
        pokemon.length > 0 && pokemon.map((item,index)=>(
          <li  key={index}> {item.name}</li>
           
        
         
        ))
      }
      </ul>
      
    </div>
  );
}

export default App;
