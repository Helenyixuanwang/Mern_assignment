
import './App.css';
import Header from './components/Header';
import AboutMe from './components/AboutMe';
import Project from './components/Project';

function App() {

  const projectData = [
    {
      title:"Window Wizard",
      likesCount: 3 ,
      description:"College student window wishing",
    },
    {
      title:"Rescue Puppies",
      likesCount: 13 ,
      description:"Find a foster family for puppies",
    },
    {
      title:"Restroom Rater",
      likesCount: 2 ,
      description:"Let's rate the restroom",
    },
    {
      title:"Window Wizard",
      likesCount: 3 ,
      description:"College student window wishing",
    },
    {
      title:"Rescue Puppies",
      likesCount: 13 ,
      description:"Find a foster family for puppies",
    },
    {
      title:"Restroom Rater",
      likesCount: 2 ,
      description:"Let's rate the restroom",
    },

  ]
  return (
    <div className="App">
      <Header />
      <AboutMe />
      {
        projectData.map((singleProjectObj)=> (
          <Project 
          title = { singleProjectObj.title }
          likesCount = { singleProjectObj.likesCount }
          description = { singleProjectObj.description } 
          />
        ))
      }
      
      
     
    </div>
  );
}

export default App;
