import React from 'react';

const Header = (props) => {
    return (
        <div>
            <h1>Welcome to my portfolio!</h1>
            <button style={{backgroundColor:"lightblue"}}>home</button>
            <button>Projects</button>
            <button>About Me</button>
            <button>Contact Me</button>

        </div>
    )
}

export default Header;