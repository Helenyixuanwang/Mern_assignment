import React, { useState } from 'react';

const Project = (props) => {
    //destructure props
    const {title, likesCount, description} = props;
    //set initial value you want it to display
    //returns a stateful(getter) value and a function to update it(setter)
    const [ likes, setLikes ] = useState(likesCount);
    const [ hasLiked, setHasLiked] = useState(false);
    const likesClickHandler = (event) => {
        let newLikes = likes + 1;
        console.log("new likes is "+ newLikes);
        //set new value for likes in memory and notify react that it need update the DOM for this component only
        setLikes(newLikes);
        setHasLiked(true);
    }
    const disLikesClickHandler = (event) => {
        let newLikes = likes - 1;
        console.log("new likes is "+ newLikes);
        //set new value for likes in memory and notify react that it need update the DOM for this component only
        setLikes(newLikes);
        setHasLiked(false);
    }
    return (
        <div style={{border:"1px solid black", padding:"5px", margin:"10px",width:"470px", height:"200px", display:"inline-block",}}>
            <h4>{ title }</h4>
            {/* when the button is clicked, it will excute the function */}
            <button onClick={(event) => likesClickHandler(event)}
            disabled={hasLiked}>Like Project</button>
            {/* use changeable stata but not sth from props, props is immutable */}
            <button onClick = { (event) => disLikesClickHandler(event) }
            disabled={ !hasLiked }>Dislike project </button>
>            <h4>Likes:{ likes }</h4>
            <div>Description</div>
            <div>{ description }</div>
        </div>
    )
}

export default Project;