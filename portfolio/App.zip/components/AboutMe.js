import React from 'react';

const AboutMe = (props) => {
    return (
        <div>
            <h4>This is about me!</h4>
            <p style={ {width:"400px", textAlign:"left", margin:"auto"}}>Reach out do i have consent to record this meeting nor gage [sic] where the industry is heading and give back to the community what we’ve learned. If you're not hurting you're not winning we need to socialize the comms with the wider stakeholder community i also believe it's important for every member to be involved and invested in our company and this is one way to do so high performance keywords synergize productive mindfulness.</p>
        </div>
    )
}

export default AboutMe;