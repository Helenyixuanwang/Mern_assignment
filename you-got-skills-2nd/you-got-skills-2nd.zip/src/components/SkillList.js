import React from 'react';
const SkillList = (props) => {
    const { listOfSkills } = props;

    return (  
        <div>
            {
                listOfSkills.map((item,index)=> 
                <p key={index}>
                 skill Name:   {item.name} <br/ >
                skill Level:   {item.level}
                </p>)
            }
        </div>
    )
}
 
export default SkillList;