import React, { useState } from 'react';

const Input = (props) => {
    const {  submitHandler} = props;

    //state that is Not shared or lifted can be used to store things
    // that are specific to this component ONLY
    const [ skillName, setSkillName] = useState("");
    const [ skillLevel, setSkillLevel] = useState(5);

    const submitSkill = (e)=> {
        e.preventDefault();
        
        //use our local state to create a new object 
        //to be added to listOfSkills state in App.js
        let newSkill = {
            name: skillName,
            level : skillLevel,
        }
        //add this new object to the listOfSkills state in App.js
        submitHandler(newSkill);
        //reset the form to default
        setSkillName("");
        setSkillLevel(5);

    }
   return (
       <div>
           <h4>Skills Form</h4>
           <form onSubmit={ submitSkill}>
               <input
               type="text"
               name="skillName"
               onChange={(e)=> setSkillName(e.target.value)}
               value={ skillName}
               />
               <input
               type="number"
               name="skillLevel"
               min="1"
               max="10"
               onChange={(e)=> setSkillLevel(e.target.value)}
               value={ skillLevel}
               />
               <br />
               {
                   skillName.length >0 ?
                   <input type="submit" value="Add Skill" />
                   :
                   <>
                   <span>You must enter a skill to submit the form
                       <input type="submit" value="Add Skill" disabled={ true } />
                   </span>
                   </>
               }
           </form>
       </div>
   )
}

export default Input;