const Footer = ()=> {
    return (
        <img className="footer-img" src='./you-got-skills.jpg' alt="you-got-skill" />
    )
}

export default Footer;