
import './App.css';
import React, {useState} from 'react';

import Footer from './components/Footer';
import Input from './components/Input';
import SkillList from './components/SkillList';

function App() {
  // const [skill, setSkill] = useState({
  //   name:"",
  //   level:5,
  // });
  const [ listOfSkills, setListOfSkills] = useState([]);

  //take in a new skill object to add to the list of skills
  const submitHandler = (newSkill) => {
    //prevented default action in the Input form already
    //e.preventDefault();
    
    if(newSkill.name.length === 0) {
      return;
    }
    
    setListOfSkills([newSkill,...listOfSkills]);
   // setSkill("");
  }
  return (
    <div className="App">
      <h1> You Have Got Skills</h1>
      <Input
      // skill = {skill}
      // setSkill = { setSkill}
      submitHandler = { submitHandler}
      />
      <SkillList
        listOfSkills = { listOfSkills }
        />
        <Footer />
    </div>
  );
}

export default App;
