import React, { Component } from 'react';


class PersonCardClass extends Component  {
    render () {
    const { firstName, lastName, age, hairColor } = this.props;
    return (
        <div className = "text-centered">
            <h2> { lastName }, { firstName }</h2>
            <p> age : { age }</p>
            <p> haircolor : { hairColor }</p>
            
        </div>
    );
    
    }
}
    


export default PersonCardClass;