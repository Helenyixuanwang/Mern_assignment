const Product = require('../models/product.model');    /* this is new */

module.exports.getAll = (req,res) => {
    Product.find()
    .then((allProducts) => {
        console.log("inside get all");
        console.log(allProducts);
        res.json(allProducts);
    })
    .catch((err) => {
        console.log(err);
        res.json({errMsg: err});
    })
};

module.exports.create =  (req,res) => {
    console.log("inside create");
    console.log(req.body); //holds the json object that we use for create
    Product.create(req.body)
    .then((newproduct)=> {
        console.log(newproduct);
        res.json(newproduct);
    })
    .catch((err)=> {
        console.log(err);
        //change the response object status to 400 so the client can see the error then send
        //the err in json back to the client
        res.status(400).json(err);
        
    })
}

module.exports.getOne = (request, response) => {
    console.log("inside getOne");
    console.log("looking for id "+ request.params.id);
    Product.findOne({_id:request.params.id})
        .then(person => response.json(person))
        .catch(err => response.json(err))
}

