import React, { useEffect, useState } from 'react'
import axios from 'axios';
const Detail = (props) => {
    const [productType, setProductType] = useState({})
    
    
    useEffect(() => {
        axios.get("http://localhost:8000/api/products/" + props.id)
            .then(res => {
                console.log(res.data);
                setProductType(res.data);
            })
            .catch((err)=> console.log(err))
                
            
    }, [])
    return (
        <div style={{marginTop:"50px", }}>
            
            <h3 style={{fontSize:"50px"}}> { productType.title }</h3>
            <p>Price: $ { productType.price }</p>
            <p> Description: { productType.description}</p>
        </div>
    )
}
export default Detail;
