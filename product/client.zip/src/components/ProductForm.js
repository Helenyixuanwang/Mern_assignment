import React, { useState } from 'react'
import axios from 'axios';
const ProductForm = (props) => {
    //keep track of what is being typed via useState hook
   const [title, setTitle] = useState("");
   const [price, setPrice ] = useState("");
   const [description, setDescription] = useState("");
   const {formSubmittedBoolean, setFormSubmittedBoolean} = props;
    //handler when the form is submitted
    const onSubmitHandler = e => {
        //prevent default behavior of the submit
        e.preventDefault();
        //make a post request to create a new product
        axios.post('http://localhost:8000/api/products', {
            title,    
            price,
            description,     
        })
            .then(res=>{
                console.log(res);
            setFormSubmittedBoolean(!formSubmittedBoolean);
            })
            .catch(err=>console.log(err))
    }
    //onChange to update firstName and lastName
    return (
        <form onSubmit={onSubmitHandler} className="form-div">
            <p>
                <label>Title</label><br/>
                <input type="text" value = {title} onChange = {(e)=>setTitle(e.target.value)}/>
            </p>
            <p>
                <label>Price</label><br/>
                <input type="text" value = {price} onChange = {(e)=>setPrice(e.target.value)}/>
            </p>
            <p>
                <label>Description</label><br/>
                <input type="text" value = {description} onChange = {(e)=>setDescription(e.target.value)}/>
            </p>
            <div>
                <button type="submit" className="submit-btn">create</button>
            </div>
        </form>
    )
}
export default ProductForm;
