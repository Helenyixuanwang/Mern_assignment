import React from 'react';
import axios from 'axios';
import { Link } from '@reach/router';
import Delete from './Delete';

const ProductList = (props) => {
    
    const { formSubmittedBoolean, setFormSubmittedBoolean} = props;
    const { product, setProduct } = props;

    const updateAfterDelete=(deletedProductId)=> {
        const filteredArray = product.filter((productObj)=>{
        //if return true, the object is part of part of new array
        //if retur false, the object is skipped in the new array
            return productObj._id !== deletedProductId;
        });
        
        setProduct(filteredArray);
    }
    
    return (
        <div>
            <table>
                <thead>
                    <th> Content      </th>
                    <th> Action available</th>
                </thead>
                <tbody>
                {props.product.map((product, idx)=>(
                <tr key={idx}>
                    <td>
                 <Link to ={"/products/"+product._id}>{ product.title} </Link>
                 </td>
                 <td>
               <span className="edit-btn"><Link to={"/products/" + product._id + "/edit"}>  Edit  </Link></span>
                <Delete productId={ product._id} afterDelete={updateAfterDelete}/>
               </td>
                </tr>
            ))
            }
                </tbody>
            </table>
           
        </div>
    )
}
export default ProductList;

