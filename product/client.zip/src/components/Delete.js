import React , { useEffect, useState } from 'react';
import axios from 'axios';
import { link, navigate } from '@reach/router';

const Delete = (props) => {
    const { productId, afterDelete } = props;
    

    const deleteHandler=()=> {
        console.log("Delete Id is "+productId);
        axios.delete("http://localhost:8000/api/products/"+ productId)
        .then((res)=>{
            console.log("product deleted: ");
            console.log(res.data);
            //run the specific code for after the delete is successful
            afterDelete(productId);

        } )
        .catch((err)=> console.log(err))

    }

    return(
        <button className="delete-btn" onClick={deleteHandler}>
        Delete 
        </button>
    )
}

export default Delete;

