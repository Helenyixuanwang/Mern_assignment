import React from 'react';

const Navigation = ()=> {
    return(
        <div style={{
            display:"inline-block",
            backgroundColor:"#6fa8dc",
            width:"140px",
            minHeight:"300px",
            border:"2px solid black",
            verticalAlign:"top",
            marginRight:"30px",
            marginLeft:"-34px",
                 

        }}>
            navigation
        </div>
    )
}

export default Navigation;