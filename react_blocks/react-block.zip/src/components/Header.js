import React from 'react';

const Header = () => {
    return (
        <div className="header" style={{
                                border:"2px solid black",
                                backgroundColor:"#6aa84f",
                                marginBottom:"20px",
                                height:"100px",
                                width:"100%",

        }}>
            Header
        </div>
    )
}

export default Header;
