import React from 'react';

const SubContents = ()=> {
    return (
        <div style={{
                    border:"2px solid black",
                    width:"140px",
                    backgroundColor:"#ffd966",
                    height:"350px",
                    display:"inline-block",
                    // marginRight:"5px",
                    
                    
        }}>
            subcontents
        </div>
    )
}

export default SubContents;