import React from 'react';

const Advertisement = ()=> {
    return (
        <div style={{
                    border:"2px solid black",
                    backgroundColor:"#b4a7d6",
                    height:"100px",
                    width:"535px",
                    marginTop:"10px",
                
        }}>
            Advertisement
        </div>
    )
}

export default Advertisement;