const Joke = require("../models/joke.model");

const getAllJokes = (req,res) => {
    Joke.find()
    .then(allJokes => res.json({ jokess: allJokes }))
    .catch(err => res.json({ message: 'Something went wrong', error: err }));
};

const addNewJoke = (req, res) =>  {
    const { body } = req;
    Joke.create({
        setup: body.setup,
        punchline: body.punchline,
    })
    .then( newJoke => res.json({newJoke : newJoke}))
    .catch((err)=>res.json({errorMsg: err}));
};

const findOneSingleJoke = (req, res) => {
    Joke.findOne({ _id: req.params.id })
        .then(oneSingleJoke => res.json({ joke: oneSingleJoke }))
        .catch(err => res.json({ message: 'Something went wrong', error: err }));
}

const updateExistingJoke = (req, res) => {
    Joke.findOneAndUpdate(
        { _id: req.params.id },
        req.body,
        { new: true, runValidators: true }
    )
        .then(updatedJoke => res.json({ joke: updatedJoke }))
        .catch(err => res.json({ message: 'Something went wrong', error: err }));
}

const deleteAnExistingJoke = (req, res) => {
    Joke.deleteOne({ _id: req.params.id })
        .then(result => res.json({ result: result }))
        .catch(err => res.json({ message: 'Something went wrong', error: err }));
}


module.exports ={
    getAllJokes,
    addNewJoke,
    findOneSingleJoke,
    updateExistingJoke,
    deleteAnExistingJoke,
};