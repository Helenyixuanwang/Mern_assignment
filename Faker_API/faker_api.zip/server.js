const express = require("express");
const faker = require("faker");
const app = express();
const port = 8000;

// Go ahead and follow the checklist below using the 2 classes below:

// User Object
// _id
// firstName
// lastName
// phoneNumber
// email
// password
// we can create a function to return a random / fake "Product"
// const createProduct = () => {
//     const newFake = {
//         name: faker.commerce.productName(),
//         price: '$' + faker.commerce.price(),
//         department: faker.commerce.department()
//     };
//     return newFake;
// };
    
// const newFakeProduct = createProduct();
// console.log(newFakeProduct);
const createUser = () => {
    const newUser = {
        _id: faker.datatype.uuid(),
        firstName: faker.name.firstName(),
        lastName: faker.name.lastName(),
        phoneNumber: faker.phone.phoneNumber(),
        email: faker.internet.email(),
        password: faker.internet.password(),
    };
    return newUser;
}

// Company Object
// _id
// name
// address
// street
// city
// state
// zipCode
// country

const createCompany = () => {
    const newCompany = {
        _id: faker.datatype.uuid(),
        name: faker.company.companyName(),
        address: faker.address.streetAddress(),
        city: faker.address.city(),
        state: faker.address.state(),
        zipcode:faker.address.zipCode(),
        country:faker.address.country(),
    };
    return newCompany;
}

// app.get("/api/users/new",(req,res) => {
//     const aUser = createUser();
//     console.log(aUser);
//     res.json(aUser);
// })
// app.get("/api/companies/new",(req,res) => {
//     const aCompany = createCompany();
//     console.log(aCompany);
//     res.json(aCompany);
// })
// make sure these lines are above any app.get or app.post code blocks
app.use( express.json() );
app.use( express.urlencoded({ extended: true }) );



app.get("/api/user/company",(req,res) => {
    const aCompany = createCompany();
    const aUser = createUser();

    console.log("New User");
    console.log(aUser);
    console.log("New company");
    console.log(aCompany);

    res.json({ user: aUser, company: aCompany });
})

app.listen( port, () => console.log(`I am listening on port: ${port}`) 

);
